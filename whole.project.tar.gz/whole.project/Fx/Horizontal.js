Horizontal (){ return; }

Horizontal [pixel]
Horizontal [volume]
Horizontal [frame]
Horizontal [detail]
