Animate Before (){ return; }
