("mp3 hsmydvideo.mp4 | sh", "mp3 :: hsmyrecord.wav | sh")
[usage]{usage+='    '+this+'\n';},bytes,

mp3( include '-I ', format '--audio: mp3', prefix 'ffmpeg',

[convert]{convert=
   this.prefix+this.include+stack+this.format;
}
"once: "{}= {console.log(this.convert(stack);}

# main stack
{try {
   if (scriptArgs[1]=="::"){
	  js.mp3.stack = scriptArgs[2]; return '';}else{
          js.mp3.stack = scriptArgs[1]; return '';}
 }catch(ex){
    console.log(ex);
    console.log("usage :\n" + js.usage());
} }
