write [html/fudge.won] { only object ( "content" ) },

load ("./html/content.html"),

html [script] {} [body] {
<h1>Page title</h1>
<div>Welcome</div><canvas/>
},

webgl [vertex] {} [fragment] {pixel = emboss+image+text;},

main { js.html.script = js.webgl.toString();
 js.write.to("html/webgl.html", js.html + "");
 return 'done.';
}


