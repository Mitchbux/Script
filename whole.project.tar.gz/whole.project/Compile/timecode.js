list timecode(
- "My playlist"

+ "00:00:00" [video] {file.mp4} start "00:00" end "03:20"
+ "00:03:20" [music] {song.mp3} start "00:00" end "03:25"
+ "00:06:45" [image] {img.jpeg}

)

main {return "";}
