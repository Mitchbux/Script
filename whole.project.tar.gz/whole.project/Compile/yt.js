("http://youtube.com/watch?v=HSMYDVIDEO", "yt :: youtu.be/HSMYDVIDEO", "yt :: HSMYDVIDEO" )
[usage]{usage+='    '+this+'\n';},bytes,
yt( shortinfo 'youtube.info/?',
    videomp4 'video src=''',
    prefix1 'youtu.be/',
    prefix2 'youtube.com/watch?v='

[getinfos]{

}

[download]{

}

"once:"){ }={
	var data=this.getinfos(stack);
	this.download(data);
	console.log("Downloading ...")
	console.log("yt::{" + stack + "} download ok.")
} ,

# main stack
{try {
   if (scriptArgs[1]=="::"){
	  js.yt.stack = scriptArgs[2]; return '';}
   else{  js.yt.stack = scriptArgs[1]; return '';}
 }catch(ex){
    console.log(ex);
    console.log("usage :\n" + js.usage());
} }
