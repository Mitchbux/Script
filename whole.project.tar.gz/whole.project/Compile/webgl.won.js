
welcome.webgl(

	[image] {./html/content.html},

	[vertex] {

	},

	[fragment] {

	},

	[text] {
		return "Welcome";
	}
)
