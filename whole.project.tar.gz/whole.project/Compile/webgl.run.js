
function widgets(ctx){var fsize=el.height/lines;
//list
var ty=1.5;
  for (var m in msgs){drawText(msgs[m], fsize, "nrm","#bbb",30,ty++*(fsize)); if (ty==1.5)ty=2.;}

var d=document;var st=d.createElement("style");st.appendChild(d.createTextNode("@font-face{font-family:'nrm';src:local('nrm'),url('"+font+"')format('truetype');}"));cn("12").appendChild(st);
var tc=d.createElement("canvas");tc.style="display:none";d.body.style="padding:0;margin:0;background-color:#000;";d.body.appendChild(tc),bkg=d.createElement("img");bkg.style="display:none";bkg.src=background;d.body.appendChild(bkg);el=cn("120");ht=cn("1"),gl=el.getContext("webgl"),ctx=0;
/*iID = setInterval(drawScene, 200);*/  var index=3;var minline=lines*0.395;var p=0.0;
function drawText(str, size, fnt, color, x, y) {ctx.font = size + 'px "'+fnt+'"'; ctx.textBaseline = 'top';ctx.fillStyle = color;ctx.fillText(str, x, y);}
function drawCircle(x,y,size,color){ ctx.beginPath();ctx.fillStyle=color;ctx.arc(el.width*0.5+x,el.height*0.8+y,size,0,Math.PI*2.0);ctx.fill();}
function rsz(){el.style.backgroundColor="#000";tc.width = el.width = document.documentElement.clientWidth; tc.height = el.height = document.documentElement.clientHeight;gl.viewport(0, 0, el.width, el.height);ctx = tc.getContext("2d"); ctx.fillStyle="#000";ctx.fillRect(0,0,el.width,el.height);widgets(ctx);drawScene();}rsz();document.onload = rsz;window.ondeviceorientation = rsz;window.onresize=rsz;
gl.clearColor(0.08, 0.1, 0.15, 1); gl.clear(gl.COLOR_BUFFER_BIT);function sh(g, t, x) {r = g.createShader(t);g.shaderSource(r, x);g.compileShader(r);return r;};vs = sh(gl, gl.VERTEX_SHADER, s[0]); fs = sh(gl, gl.FRAGMENT_SHADER, s[1]);
var pr=gl.createProgram();gl.attachShader(pr, vs);gl.attachShader(pr, fs);gl.linkProgram(pr);gl.useProgram(pr);
var a=gl.getAttribLocation(pr, "a"), buffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, buffer);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 0, 0);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,0,-1,1,0,1,-1,0,1,1,0]), gl.STATIC_DRAW);
function tprm(tex) {gl.bindTexture(gl.TEXTURE_2D, tex);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);}
function teximg(tex, img) {gl.bindTexture(gl.TEXTURE_2D, tex);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);}
function unitex(tex, id, i, uni) {gl.activeTexture(id);gl.bindTexture(gl.TEXTURE_2D, tex);gl.uniform1i(gl.getUniformLocation(pr, uni), i);}
var tx=[gl.createTexture(), gl.createTexture()];for(var t in tx)tprm(tx[t]);
var pass=0;function drawScene() {try{ gl.uniform1f(gl.getUniformLocation(pr, "pindex"), lines-index-1.5);gl.uniform1f(gl.getUniformLocation(pr, "lines"), lines);teximg(tx[0], tc);if(pass<5){teximg(tx[1],bkg); pass++;}unitex(tx[0], gl.TEXTURE1, 1, "txt");unitex(tx[1], gl.TEXTURE2, 2, "bkg");gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);}catch(e){console.log(e);}}

el.ontouchstart = function(e){if (e.changedTouches)e.preventDefault();
ix=((e.changedTouches[0].pageY/el.height)*lines)>>0;
if (ix<=msgs.length)index = ix; if (index<1)index=1;  rsz();};
el.onclick = function(e){ix=((e.pageY/el.height)*lines)>>0;if (ix<=msgs.length)index=ix;if (index<1)index=1; rsz();};

