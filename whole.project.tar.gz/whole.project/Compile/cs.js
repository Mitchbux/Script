("qs :: myownid", "qs upload.zip")
[usage]{usage+='    '+this+'\n';},bytes,
cs( create 'is.gd/create.php?url=', 
    forward 'is.gd/forward.php?shorturl=', 
    prefix 'www.ok.com/#',

[upload]{

}

[download]{

}

"once:") {
	var qid = this.upload(js.load.first);
	console.log("Uploading...");
	return "Upload qs::{"+qid+"} ok.";
}={
	var data=this.download(stack);
	console.log("Downloading ...")
	console.log("qs::{" + stack + "} download ok.")
} ,

# main stack
{try {
   if (scriptArgs[1]=="::"){
	  js.qs.stack  = scriptArgs[2];return '';}
   else{  js.load.push(scriptArgs[1]); return js.qs;}
 }catch(ex){
    console.log(ex);
    console.log("usage :\n" + js.usage());
} }
