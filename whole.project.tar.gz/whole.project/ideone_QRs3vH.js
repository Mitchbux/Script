// your code goes here

//globals
var js=[], ws=js, ps=ws;

//Array extension
Array.prototype.index = 0;

Array.prototype.forEach = function(stack, body){
  for(var key=0;key<this.length;key++) body.apply(this[key], [stack]);}
Array.prototype.add = Array.prototype.push;
Object.defineProperty(Array.prototype,"first",
{get: function(){return this[this.index=0];},
 set: function(v){this[this.index=0] = v;}});
Object.defineProperty(Array.prototype,"next",
{get: function(){return this[this.index<this.length?++this.index:this.length];},
 set: function(v){this[this.index<this.length?++this.index:this.length]=v;}});
Object.defineProperty(Array.prototype, "theFirst",
{get: function(){return (this.index==0);}});

Array.prototype.plus = function(){
if (!this[-1]){this[-1] = [,[]];
}else this.pus++;
return this[this.mus][this.pus]=[];}

Array.prototype.minus = function(){
if (!this[-1]){this[-1] = [,[]];
}else this.mus--; this.pus=0;
return this[this.mus]=[];}

Array.prototype.mus = -1;
Array.prototype.pus = 1;
Array.prototype.getter = function(){ return this.join(""); }
Array.prototype.toString = function(){return this.getter();}
Array.prototype.setter = function(v){ this["="]=v;}
Array.prototype.indexer = function(n,b){
var e ="this.{name} = function(v){var {name} = ''; this.forEach(v, function(stack){" +
b + "}); return {name}; };"; eval(e.replace("{name}",n)); };

Object.defineProperty(Array.prototype,"stack",
{
get: function(){ return this.getter();},
set: function(v){ return this.setter(v);}
}
);

//String extension

String.prototype.after =function (a){var s=this; if (s.indexOf(a)>-1)return s.substring(s.indexOf(a)+a.length);else return empty;}
String.prototype.before = function (b){var s=this; if (s.indexOf(b)>-1) return s.substring(0,s.indexOf(b));else return empty;}
String.prototype.replace = function(a,b){return this.split(a).join(b);}


//your code here


ws.push("Hello");
ws.push("World");

ws=js.ok=[];
ws.push("Hey there, ");

ps=ws.plus();
ps.push("bye");
ps.push("bye");

ps=ws.minus();
ps.push("bye");
ps.push("bye");

ws=ps.plays=[];
ws.push("Bye...");

ws=js;
ws.indexer("those", "those += ': '+this;");

ws=js.ok;
ws.setter = function(stack){console.log(stack);};
ws.getter = function(){return this.first + " dypers";}

console.log(js.ok);
console.log(js.those("clear"));
console.log(js.join(" / ").replace("o", "0"));
js.ok.stack = js.ok[-2].plays;
console.log(js.ok[-1][1]);
