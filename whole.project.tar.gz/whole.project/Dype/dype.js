("-port NN", "-once")
[usage]{usage='   '+this+'\n'}

dype(
	port '80', extension ".webjs"
	once 'false',
	request (url "/", filename "index.js", params ""),

[serve]{
	var bytes=stack;
	if (js.dype.filename.after(js.dype.extension)==""){
		bs = []; buildWON.node = "bs";
		js.WON(stack); bytes = bs.toString();
	}
	serve=bytes;
}

"loop:"){}= {/*build parameters and loop request*/},

{ try{
	js.dype.stack = scriptArgs;
}catch(ex){
	console.log(ex.toString()); console.log('usage:\n' + js.usage());
} }



