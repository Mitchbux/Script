#include "SFML.hpp"
#include "ffmpeg.h"

//todo : quick js extension for opengl windowed Simple-Browser
//- use screenshotKit for text 7 image rendering to jpeg/png
//- use libjpeg/libpng to load texture and mix them together
//- use webgl fragment & render 3d-context compliant external
//- render simple geometry in a pre-numbered vertex shader
//- use timecode from js.js to play song & movies
//use [output] module to render .mp4 file format
//convert ffmpeg filters to simple js notation

