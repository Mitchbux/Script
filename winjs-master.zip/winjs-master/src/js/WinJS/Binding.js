define([
    './Binding/_BindingParser',
    './Binding/_Data',
    './Binding/_Declarative',
    './Binding/_DomWeakRefTable'], function () {
    //Wrapper module
});