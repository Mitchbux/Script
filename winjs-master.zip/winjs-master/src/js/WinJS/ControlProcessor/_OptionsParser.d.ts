export declare function optionsParser(options: string, context?: any, functionContext?: any): any;
