// Copyright (c) Microsoft Corporation.  All Rights Reserved. Licensed under the MIT License. See License.txt in the project root for license information.
define([
    './VirtualizedDataSource/_VirtualizedDataSourceImpl',
    './VirtualizedDataSource/_GroupDataSource',
    './VirtualizedDataSource/_GroupedItemDataSource',
    './VirtualizedDataSource/_StorageDataSource'
     ], function () {

    //wrapper module
});