// Copyright (c) Microsoft Corporation.  All Rights Reserved. Licensed under the MIT License. See License.txt in the project root for license information.
define([
    'WinJS/Controls/ScrollViewer',

    'require-style!less/styles-tv',
    'require-style!less/colors-tv'
], function (ScrollViewer) {
});