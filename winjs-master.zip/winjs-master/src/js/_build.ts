// Copyright (c) Microsoft Corporation.  All Rights Reserved. Licensed under the MIT License. See License.txt in the project root for license information.

// This file exists here in order to have the correct build structure until we convert more files to typescript