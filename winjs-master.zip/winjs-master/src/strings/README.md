# winjs-localization

This directory contains the localized versions of each string WinJS uses. To localize WinJS when using it in a Windows Store App:

1. Add this directory to your WinJS project in Visual Studio.
2. This directory contains one folder per language. Delete the folders for the languages your app will **not** be available in.

That's it. Your app will now use the localized WinJS resources for the appropriate language.