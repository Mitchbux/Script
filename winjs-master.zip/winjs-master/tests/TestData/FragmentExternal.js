// Copyright (c) Microsoft Corporation.  All Rights Reserved. Licensed under the MIT License. See License.txt in the project root for license information.
function fragmentWithExternalScriptAndStylesLoad(elements, options) {
    "use strict";
    elements.querySelector(".findme2").innerHTML = "hit";
}

function fragmentWithExternalScriptAndStylesLoadFunc() {
    return 1;
}