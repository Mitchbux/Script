folder.fs (
[html/content.html]{yourhtmlcontenthere}
)

