# application utils
("qs :: myownid", "qs upload.zip")
[usage] { usage+=js.t+this+'\n';}, t "    ",
bytes { return loadFile(this.first); }

configuration(
create "https://is.gd/?create&url=",
prefix "http://www.ok.com/#",
lookup "https://is.gd/lookup?shorturl=")

# main code :: upoload
qs {

	var qid = "01234";

	console.log("Uploading...");

	//upload

	return "Upload qs::{"+qid+"} ok.";
} = {

	var data=js.bytes;

	console.log("Downloading ...")

	//decode

	console.log("qs::{" + stack + "} download ok.")
}

# main method
{try {if (scriptArgs[1]=="::"){
js.qs.stack  = scriptArgs[2];}else{	
js.bytes.push(scriptArgs[1]); console.log(js.qs);}}
catch(ex){console.log(ex);console.log("usage :\n" + js.usage());}}
