//module imports
import {loadFile} from "std";

//globals
var js=[], ws=js, ps=ws;

//Array extension
Array.prototype.index = 0;
Array.prototype.forEach = function(value, body){for(var key=0;key<this.length;key++) body.apply(this[key], [value]);}
Array.prototype.add = Array.prototype.push;
Object.defineProperty(Array.prototype,"first",
{get: function(){return this[this.index=0];},
 set: function(v){this[this.index=0] = v;}});
Object.defineProperty(Array.prototype,"next",
{get: function(){return this[this.index<this.length?++this.index:this.length];},
 set: function(v){this[this.index<this.length?++this.index:this.length]=v;}});
Object.defineProperty(Array.prototype, "theFirst",{get: function(){return (this.index==0);}});
Array.prototype.getter = function(){ return this.join(""); }
Array.prototype.toString = function(){return this.getter();}
Array.prototype.setter = function(v){ this["="]=v;}
Array.prototype.indexer = function(n,b){var e ="this.{n} = function(v){var {n} = ''; this.forEach(v, function(stack){" +b + "}); return {n}; };"; eval(e.replace("{n}",n)); };
Object.defineProperty(Array.prototype,"stack",{
get: function(){ return this.getter();},
set: function(v){ return this.setter(v);}});

//String extension
String.prototype.after =function (a){var s=this; if (s.indexOf(a)>-1)return s.substring(s.indexOf(a)+a.length);else return empty;}
String.prototype.before = function (b){var s=this; if (s.indexOf(b)>-1) return s.substring(0,s.indexOf(b));else return empty;}
String.prototype.replace = function(a,b){return this.split(a).join(b);}


//# application utils
js = ["qs :: myownid", "qs upload.zip"]; js.indexer("usage", "usage+=js.t+this+'\\n';"); js.t = "    ";
js.bytes = [];js.bytes.getter = function(){ return loadFile(this.first); }

//# configuration
js.qs = ["","",""];

//# main code :: upoload
js.qs.getter = function(){

	var qid = "01234";

	console.log("Uploading...");

	//upload

	return "Upload qs::{"+qid+"} ok.";
}

//# main code :: download
js.qs.setter = function(stack){

	var data=js.bytes;

	console.log("Downloading ...")

	//decode

	console.log("qs::{" + stack + "} download ok.")
}

//# main method
try {if (scriptArgs[1]=="::"){	js.qs.stack  = scriptArgs[2];}else{	js.bytes.push(scriptArgs[1]); console.log(js.qs);}
}catch(ex){	console.log(ex);	console.log("usage :\n" + js.usage());}
