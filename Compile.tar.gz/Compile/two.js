consider using { return "Hello World" + this.those(); }
consider using [those] { those += this; }
consider using (" ::: / from ", "kick script", "/ :::")
