// your code goes here

//globals
var js=[], ws=js, ps=ws;

//Array extension
Array.prototype.index = 0;
Array.prototype.forEach = function(stack, body){for(var key=0;key<this.length;key++) body.apply(this[key], [stack]);}
Array.prototype.add = Array.prototype.push;
Object.defineProperty(Array.prototype,"first",{get: function(){return this[this.index=0];}, set: function(v){this[this.index=0] = v;}});
Object.defineProperty(Array.prototype,"next",{get: function(){return this[this.index<this.length?++this.index:this.length];}, set: function(v){this[this.index<this.length?++this.index:this.length]=v;}});
Object.defineProperty(Array.prototype, "theFirst",{get: function(){return (this.index==0);}});

Array.prototype.plus = function(){if (!this[-1]){this[-1] = [,[]];}else this.pus++;return this[this.mus][this.pus]=[];}
Array.prototype.minus = function(){if (!this[-1]){this[-1] = [,[]];}else this.mus--; this.pus=0;return this[this.mus]=[];}
Array.prototype.mus = -1;Array.prototype.pus = 1;

//default
Array.prototype.getter = function(){return this.join("");};
Array.prototype.toString = function(){return eval(this.getter);}
Array.prototype.setter = function(stack){this["="]=stack;};
Array.prototype.indexer = function(n,b){var e ="this.{n} = function(v){var {n} = ''; this.forEach(v, function(stack){" +b + "}); return {n}; };"; eval(e.replace("{n}",n)); };
Object.defineProperty(Array.prototype,"stack",{get: function(){ return this.getter();},set: function(stack){ return this.setter(stack);}});

//parse json & XML & WON
var fromXML = {
tag: function(obj, name){return obj[name] = [];},
attribute: function(obj, name, value){return obj["@"+name]=[];},
content: function(obj, txt){obj.add(txt); return obj;}
};
Array.prototype.XML = function(xmlstr){

}

var sys = {
text:"", until:function(){},
name: "", root: "", node: "", until:exist={}, rootStack:[]};
var buildWON = {token: "(),{}[]+=-*'\'", breaker:"(),{}[]+=-*'\" \t\r\n"};
buildWON[-1] = function(){if (sys.exist[sys.node + "." + sys.name]){ sys.node += "."+sys.name; return ""; }
else { sys.node += "."+sys.name; sys.exist[sys.node]={};return sys.node+"=[];";} };
buildWON[0] = function(){sys.rootStack.push(sys.root); sys.root = sys.node; return "ws=" + sys.node + ";";};
buildWON[1] = function(){sys.root = sys.rootStack.pop(); sys.node = sys,root;return "ws="+sys.root+";";};
buildWON[2] = function(){sys.node = sys.root; return "";};
buildWON[3] = function(){var code = sys.until("{","}",true);code="function(stack){"+code+"}";
if (sys.name=="="){return sys.node+".setter="+code+";";}
else{return sys.node+".getter="+code+";"}};
buildWON[4] = function(){};

Array.prototype.WON = function(wonstr){

}
Array.prototype.JSON = function(jsonstr){ eval("this.json="+jsonstr); }

//filesystem module
Array.prototype.load = []
Array.prototype.load.push = function(filename){this[this.length] = loadFile(filename);}
Array.prototype.filesystem = [];
Array.prototype.filesystem.indexer = function(name,data){
// if (name=="dir"){chdir(data);}
// open(name); write(data);
}

//webgl module
Array.prototype.webgl = [];
Array.prototype.webgl.indexer = function(name,code){
if (!this.module){
this.module = {image :[],
image.setter: function(stack){
this.element = document.createElement("IMG");
this.element.src = stack;
},
image.getter: function(){
return this.element;
},
  video: [],
video.setter: function(stack){
this.element = document.createElement("VIDEO");
this.element.src = stack;},
video.getter: function(){}{return this.element;},
   		 vertex :[],
vertex.setter: function(stack){this.code = stack;},
vertex.getter: function(){return this.code},
	         fragment :[],
fragment.setter: function(stack){this.code = stack;},
fragment.getter: function(){return this.code}
}; this.module[name].stack = code;};

Array.prototype.webgl.getter = function(){if (!this["module"]){return "";}else{
  
}}

//timecode module
Array.prototype.timecode = [];
Array.prototype.timecode.plus = function(){
var that = js.plus.appy(this);
if (!that.module){
that.module = {image :[],
image.setter: function(stack){
that.element = document.createElement("IMG");
that.element.src = stack;
},
image.getter: function(){
return that.element;
},
  video: [],
video.setter: function(stack){
that.element = document.createElement("VIDEO");
that.element.src = stack;},
video.getter: function(){}{return that.element;}
}; 
that.indexer = function(name, code){this[name].stack = code;};
return that};

Array.prototype.timecode.getter = function(){
}

//String extension
String.prototype.after =function (a){var s=this; if (s.indexOf(a)>-1)return s.substring(s.indexOf(a)+a.length);else return empty;}
String.prototype.before = function (b){var s=this; if (s.indexOf(b)>-1) return s.substring(0,s.indexOf(b));else return empty;}
String.prototype.replace = function(a,b){return this.split(a).join(b);}


