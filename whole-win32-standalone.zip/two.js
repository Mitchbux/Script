("script")

hello world ( 'hello' 'world' 
	[greet] { greet += '::' + this; },
{ return this.greet(); }),

# main stack
{
  console.log("starting...");
	return this.join("") 
  + js.hello.world; 
},




